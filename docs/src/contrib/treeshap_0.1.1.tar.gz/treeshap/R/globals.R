globalVariables(c("Feature", "split_index", "tree_index", ".", "node_parent", "default_left", "decision_type", "position", "cumulative",
                  "prev", "text", "contribution", "var_value", "shap_value", "reorder", "variable", "importance", "Tree", "Node", "Missing",
                  "Cover", "Yes", "No", 'Prediction', 'Decision.type'))
