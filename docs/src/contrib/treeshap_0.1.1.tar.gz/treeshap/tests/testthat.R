library(testthat)
library(treeshap)

test_check("treeshap")
